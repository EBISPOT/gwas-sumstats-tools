# Stub for Pyodide — bsub is an HPC job-submission library unused in the browser.
class bsub:
    def __init__(self, *args, **kwargs): pass
    def __call__(self, *args, **kwargs): pass
